/*
 *    Disk Array driver for HP Smart Array SAS controllers
 *    Copyright 2016-2017 Microsemi Corporation
 *    Copyright 2014-2016 PMC-Sierra, Inc.
 *    Copyright 2000,2009-2015 Hewlett-Packard Development Company, L.P.
 *
 *    This program is free software; you can redistribute it and/or modify
 *    it under the terms of the GNU General Public License as published by
 *    the Free Software Foundation; version 2 of the License.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, GOOD TITLE or
 *    NON INFRINGEMENT.  See the GNU General Public License for more details.
 *
 *    You should have received a copy of the GNU General Public License
 *    along with this program; if not, write to the Free Software
 *    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *    Questions/Comments/Bugfixes to esc.storagedev@microsemi.com
 *
 */

/*
 * The following #defines allow the hpsa driver to be compiled for a 
 * variety of kernels.  Despite having names like RHEL6, SLES11, these
 * are more about the kernel than about the OS.  The Makefile.alt will
 * address the necessary settings for know OS kernels and kernel.org
 * kernels.
 *
 * If you have some intermediate kernel which doesn't quite match any of
 * the predefined sets of kernel features here, you may have to make your own 
 * define for your particular kernel and mix and match the kernel features
 * to fit the kernel you're compiling for.  How can you tell?  By studying
 * the source of this file and the source of the kernel you're compiling for
 * and understanding which "KFEATURES" your kernel has.
 *
 * Usually, if you get it wrong, it won't compile, but there are no doubt
 * some cases in which, if you get it wrong, it will compile, but won't
 * work right.  In any case, if you're compiling this, you're on your own
 * and likely nobody has tested this particular code with your particular
 * kernel, so, good luck, and pay attention to the compiler warnings.
 *
 */

/* #define RHEL6u5 */
/* #define RHEL7u1 */
/* Default is kernel.org */

/* ----- RHEL5 variants --------- */
#if \
	defined(RHEL5U0) || \
	defined(RHEL5U1) || \
	defined(RHEL5U2) || \
	defined(RHEL5U2) || \
	defined(RHEL5U3) || \
	defined(RHEL5U4) || \
	defined(RHEL5U5) || \
	defined(RHEL5U6) || \
	defined(RHEL5U7) || \
	defined(RHEL5U8) || \
	defined(RHEL5U9) || \
	defined(RHEL5U10)
#error "Sorry, hpsa will no longer work on RHEL5.  The scatter gather DMA mapping API of RHEL5 is too old."
#endif


/* ----- RHEL6 variants --------- */
#if \
	defined (RHEL6U0) || \
	defined (RHEL6U1) || \
	defined (RHEL6U2) || \
	defined (RHEL6U3) || \
	defined (RHEL6U4) || \
	defined (RHEL6U5) || \
	defined (RHEL6U6) || \
	defined (RHEL6U7) || \
	defined (RHEL6U8) || \
	defined (RHEL6U9) || \
	defined (RHEL6U10)
#define RHEL6
#endif


/* ----- RHEL7 variants --------- */
#if \
	defined (RHEL7U0) || \
	defined (RHEL7U1) || \
	defined (RHEL7U2) || \
	defined (RHEL7U3) || \
	defined (RHEL7U4) || \
	defined (RHEL7U5) || \
	defined (RHEL7U6) || \
	defined (RHEL7U7) || \
	defined (RHEL7U8) || \
	defined (RHEL7U9)
#define RHEL7
#endif

/* ----- RHEL8 variants --------- */
#if \
	defined (RHEL8U0) || \
	defined (RHEL8U1) || \
	defined (RHEL8U2) || \
	defined (RHEL8U3) || \
	defined (RHEL8U4) || \
	defined (RHEL8U5) || \
	defined (RHEL8U6)
#define RHEL8
#endif


/* ----- SLES11 variants --------- */
#if \
	defined (SLES11SP0) || \
	defined (SLES11SP1) || \
	defined (SLES11SP2) || \
	defined (SLES11SP3) || \
	defined (SLES11SP4)

#define SLES11
#define SLES11sp2plus

#if defined (SLES11SP0)
#undef SLES11sp1
#undef SLES11sp2plus
#endif

#if defined (SLES11SP1)
#define SLES11sp1
#undef SLES11sp2plus
#endif
#endif


/* ----- SLES12 variants --------- */
#if \
	defined (SLES12SP0) || \
	defined (SLES12SP1) || \
	defined (SLES12SP2) || \
	defined (SLES12SP3)
#define SLES12
#endif

/* ----- SLES15 variants --------- */
#if \
	defined(SLES15SP0) || \
	defined(SLES15SP1) || \
	defined(SLES15SP2) || \
	defined(SLES15SP3) || \
	defined(SLES15SP4)
#define SLES15
#endif

/* Define common kernel features */

#define HPSA_SUPPORTS_STORAGEWORKS_1210m 1
#define KFEATURE_HAS_2011_03_INTERRUPT_HANDLER 1
#define KFEATURE_HAS_2011_03_STYLE_DEVICE_ATTR 1
#define KFEATURE_HAS_NEW_DMA_MAPPING_ERROR 1
#define KFEATURE_HAS_SCSI_DEVICE_TYPE 1
#define KFEATURE_HAS_SCSI_DMA_FUNCTIONS 1
#define KFEATURE_HAS_SCSI_FOR_EACH_SG 1
#define KFEATURE_HAS_SCSI_QDEPTH_DEFAULT 1
#define KFEATURE_HAS_SCSI_SET_RESID 1
#define KFEATURE_HAS_SHOST_PRIV 1
#define KFEATURE_HAS_UACCESS_H_FILE 1
#define KFEATURE_SCAN_START_IMPLEMENTED 1
#define KFEATURE_SCAN_START_PRESENT 1
#define SA_CONTROLLERS_GEN8 1
#define SA_CONTROLLERS_GEN8_2 1
#define SA_CONTROLLERS_GEN8_5 1
#define SA_CONTROLLERS_GEN9 1
#define PMC_CONTROLLERS_GEN1 1

/* Define kernel features per distro... */

#if defined(RHEL6)/************ RHEL 6 ************/
#define KFEATURE_HAS_WAIT_FOR_COMPLETION_IO_TIMEOUT 0
#define KFEATURE_HAS_WAIT_FOR_COMPLETION_IO 0
#define KFEATURE_CHANGE_QDEPTH_HAS_REASON 1
#define KFEATURE_CHANGE_QUEUE_TYPE 1
#define KFEATURE_HAS_2011_03_QUEUECOMMAND 0
#define KFEATURE_HAS_SMP_LOCK_H 1
#define KFEATURE_HAS_IRQ_SET_AFFINITY_HINTS 1
#define KFEATURE_HAS_ALLOC_WORKQUEUE 0
#define KFEATURE_HAS_PHY_SETUP_AND_RELEASE 0
#define SA_CONTROLLERS_GEN6 1
#define KFEATURE_HAS_EH_TIMEOUT 1
#define KFEATURE_HAS_ENABLE_CLUSTERING 1
#define HPSA_IOCTL_INT int

#if defined (RHEL6U8) || defined (RHEL6U9) || defined (RHEL6U10)
#define KFEATURE_HAS_ATOMIC_DEC_IF_POSITIVE 1
#else
#define KFEATURE_HAS_ATOMIC_DEC_IF_POSITIVE 0
#endif

#if defined (RHEL6U0) || defined (RHEL6U1)
/* RHEL6 base and update 1 do not have .lockless field in SCSI host template
 * but RHEL6u2 and onwards do.
 */
#define KFEATURE_HAS_HOST_LOCKLESS_FIELD 0
#else
#define KFEATURE_HAS_HOST_LOCKLESS_FIELD 1
#endif

/* ... else it's not RHEL6 */
#elif defined(SLES11)
#define KFEATURE_HAS_WAIT_FOR_COMPLETION_IO_TIMEOUT 0
#define KFEATURE_HAS_WAIT_FOR_COMPLETION_IO 0
#define KFEATURE_CHANGE_QDEPTH_HAS_REASON 1
#define KFEATURE_CHANGE_QUEUE_TYPE 1
#define KFEATURE_HAS_HOST_LOCKLESS_FIELD 0
#define KFEATURE_HAS_PHY_SETUP_AND_RELEASE 0
#define SA_CONTROLLERS_GEN6 0
#define KFEATURE_HAS_ENABLE_CLUSTERING 1
#define HPSA_IOCTL_INT int
#define KFEATURE_HAS_EH_TIMEOUT 0

#ifdef SLES11sp1 /************* SLES11 sp1 ********/
#define KFEATURE_HAS_SMP_LOCK_H 1
#define KFEATURE_HAS_2011_03_QUEUECOMMAND 0
#define KFEATURE_HAS_IRQ_SET_AFFINITY_HINTS 0
#define KFEATURE_HAS_ALLOC_WORKQUEUE 0
#define KFEATURE_HAS_ATOMIC_DEC_IF_POSITIVE 0
#define KFEATURE_HAS_PHY_SETUP_AND_RELEASE 0
#define VERIFY_12 0xAF
#define KFEATURE_HAS_EH_TIMEOUT 0
#endif

#ifdef SLES11sp2plus /************* SLES11 sp2 and after ********/
#define KFEATURE_HAS_SMP_LOCK_H 0
#define KFEATURE_HAS_2011_03_QUEUECOMMAND 1
#define KFEATURE_HAS_IRQ_SET_AFFINITY_HINTS 1
#define KFEATURE_HAS_ALLOC_WORKQUEUE 1
#define KFEATURE_HAS_ATOMIC_DEC_IF_POSITIVE 1
#define KFEATURE_HAS_PHY_SETUP_AND_RELEASE 0
#define KFEATURE_HAS_EH_TIMEOUT 0
#endif

/* ... else not SLES11 */
#elif defined(RHEL7) /************ RHEL 7 ************/
#define KFEATURE_HAS_WAIT_FOR_COMPLETION_IO_TIMEOUT 1
#define KFEATURE_HAS_WAIT_FOR_COMPLETION_IO 1
#define KFEATURE_CHANGE_QDEPTH_HAS_REASON 1
#define KFEATURE_CHANGE_QUEUE_TYPE 1
#define KFEATURE_HAS_2011_03_QUEUECOMMAND 1
#define KFEATURE_HAS_HOST_LOCKLESS_FIELD 0
#define KFEATURE_HAS_SMP_LOCK_H 0 /* include/linux/smp_lock.h removed between 2.6.38 and 2.6.39 */
#define KFEATURE_HAS_IRQ_SET_AFFINITY_HINTS 1
#define KFEATURE_HAS_ALLOC_WORKQUEUE 1
#define KFEATURE_HAS_ATOMIC_DEC_IF_POSITIVE 1
#define KFEATURE_HAS_PHY_SETUP_AND_RELEASE 1
#define SA_CONTROLLERS_GEN6 1
#define KFEATURE_HAS_NEWER_ALLOC_ORDERED_WORKQUEUE 1
#define KFEATURE_HAS_EH_TIMEOUT 1
#define KFEATURE_HAS_ENABLE_CLUSTERING 1
#define HPSA_IOCTL_INT int

/* ... else not RHEL7 */
#elif defined(KCLASS3A) /************ Kernel Class 3A ************/
#define KFEATURE_HAS_WAIT_FOR_COMPLETION_IO_TIMEOUT 0
#define KFEATURE_HAS_WAIT_FOR_COMPLETION_IO 0
#define KFEATURE_CHANGE_QDEPTH_HAS_REASON 1
#define KFEATURE_CHANGE_QUEUE_TYPE 1
#define KFEATURE_HAS_2011_03_QUEUECOMMAND 1
#define KFEATURE_HAS_HOST_LOCKLESS_FIELD 0
#define KFEATURE_HAS_SMP_LOCK_H 0 /* include/linux/smp_lock.h removed between 2.6.38 and 2.6.39 */
#define KFEATURE_HAS_IRQ_SET_AFFINITY_HINTS 1
#define KFEATURE_HAS_ALLOC_WORKQUEUE 1
#define KFEATURE_HAS_ATOMIC_DEC_IF_POSITIVE 1
#define KFEATURE_HAS_PHY_SETUP_AND_RELEASE 0
#define SA_CONTROLLERS_GEN6 1
#define KFEATURE_HAS_ENABLE_CLUSTERING 1
#define HPSA_IOCTL_INT int

/* ... else not KCLASS3A */
#elif defined(KCLASS3B)/************ Kernel Class 3B ************/
#define KFEATURE_HAS_WAIT_FOR_COMPLETION_IO_TIMEOUT 0
#define KFEATURE_HAS_WAIT_FOR_COMPLETION_IO 0
#define KFEATURE_CHANGE_QDEPTH_HAS_REASON 1
#define KFEATURE_CHANGE_QUEUE_TYPE 1
#define KFEATURE_HAS_2011_03_QUEUECOMMAND 1
#define KFEATURE_HAS_HOST_LOCKLESS_FIELD 0
#define KFEATURE_HAS_SMP_LOCK_H 0 /* include/linux/smp_lock.h removed between 2.6.38 and 2.6.39 */
#define KFEATURE_HAS_IRQ_SET_AFFINITY_HINTS 1
#define KFEATURE_HAS_ALLOC_WORKQUEUE 1
#define KFEATURE_HAS_ATOMIC_DEC_IF_POSITIVE 1
#define KFEATURE_HAS_PHY_SETUP_AND_RELEASE 1
#define SA_CONTROLLERS_GEN6 1
#define KFEATURE_HAS_ENABLE_CLUSTERING 1
#define HPSA_IOCTL_INT int

/***** KCLASS3C & Early SLES12 *******/
#elif defined (KCLASS3C) || defined (SLES12SP0) || defined (SLES12SP1)
#define KFEATURE_HAS_WAIT_FOR_COMPLETION_IO_TIMEOUT 1
#define KFEATURE_HAS_WAIT_FOR_COMPLETION_IO 1
#define KFEATURE_CHANGE_QDEPTH_HAS_REASON 1
#define KFEATURE_CHANGE_QUEUE_TYPE 1
#define KFEATURE_HAS_2011_03_QUEUECOMMAND 1
#define KFEATURE_HAS_HOST_LOCKLESS_FIELD 0
#define KFEATURE_HAS_SMP_LOCK_H 0 /* include/linux/smp_lock.h removed between 2.6.38 and 2.6.39 */
#define KFEATURE_HAS_IRQ_SET_AFFINITY_HINTS 1
#define KFEATURE_HAS_ALLOC_WORKQUEUE 1
#define KFEATURE_HAS_ATOMIC_DEC_IF_POSITIVE 1
#define KFEATURE_HAS_PHY_SETUP_AND_RELEASE 1
#define SA_CONTROLLERS_GEN6 1
#define KFEATURE_HAS_EH_TIMEOUT 1
#define KFEATURE_HAS_ENABLE_CLUSTERING 1
#define HPSA_IOCTL_INT int
#elif defined(SLES15) || defined(SLES12SP4) || defined(SLES12SP5)
#define KFEATURE_HAS_WAIT_FOR_COMPLETION_IO_TIMEOUT 1
#define KFEATURE_HAS_WAIT_FOR_COMPLETION_IO 1
#define KFEATURE_HAS_PCI_ENABLE_MSIX_RANGE 1
#define KFEATURE_CHANGE_QDEPTH_HAS_REASON 0
#define KFEATURE_CHANGE_QUEUE_TYPE 0
#define KFEATURE_HAS_2011_03_QUEUECOMMAND 1
#define KFEATURE_HAS_HOST_LOCKLESS_FIELD 0
#define KFEATURE_HAS_SMP_LOCK_H 0 /* include/linux/smp_lock.h removed between 2.6.38 and 2.6.39 */
#define KFEATURE_HAS_IRQ_SET_AFFINITY_HINTS 1
#define KFEATURE_HAS_ALLOC_WORKQUEUE 1
#define KFEATURE_HAS_ATOMIC_DEC_IF_POSITIVE 1
#define KFEATURE_HAS_PHY_SETUP_AND_RELEASE 0
#define KFEATURE_HAS_BLK_RQ_FUNCTIONS 1
#define SA_CONTROLLERS_GEN6 1
#define scsi_adjust_queue_depth(a, b, c) scsi_change_queue_depth(a, c)
#define KFEATURE_HAS_EH_TIMEOUT 1
#if defined(SLES15SP2) || defined(SLES15SP3) || defined(SLES15SP4) || defined(SLES15SP5)
#define KFEATURE_HAS_ENABLE_CLUSTERING 0
#define HPSA_IOCTL_INT unsigned int
#else
#define KFEATURE_HAS_ENABLE_CLUSTERING 1
#define HPSA_IOCTL_INT int
#endif
/***** KCLASS3D & SLES12SP2/SP3 *******/
#elif defined (KCLASS3D) || defined(KCLASS4A) || defined (SLES12SP2) || defined (SLES12SP3)
#define KFEATURE_HAS_WAIT_FOR_COMPLETION_IO_TIMEOUT 1
#define KFEATURE_HAS_WAIT_FOR_COMPLETION_IO 1
#define KFEATURE_CHANGE_QDEPTH_HAS_REASON 0
#define KFEATURE_CHANGE_QUEUE_TYPE 0
#define KFEATURE_HAS_2011_03_QUEUECOMMAND 1
#define KFEATURE_HAS_HOST_LOCKLESS_FIELD 0
#define KFEATURE_HAS_SMP_LOCK_H 0 /* include/linux/smp_lock.h removed between 2.6.38 and 2.6.39 */
#define KFEATURE_HAS_IRQ_SET_AFFINITY_HINTS 1
#define KFEATURE_HAS_ALLOC_WORKQUEUE 1
#define KFEATURE_HAS_ATOMIC_DEC_IF_POSITIVE 1
#define KFEATURE_HAS_PHY_SETUP_AND_RELEASE 1
#define SA_CONTROLLERS_GEN6 1
#define scsi_adjust_queue_depth(a, b, c) scsi_change_queue_depth(a, c)
#define change_queue_type
#define KFEATURE_HAS_PCI_ENABLE_MSIX_RANGE 0
#define KFEATURE_HAS_EH_TIMEOUT 1
#define KFEATURE_HAS_ENABLE_CLUSTERING 1
#define HPSA_IOCTL_INT int
#else /* ... else Default, kernel.org & KCLASS4B & RHEL8 */
#define KFEATURE_HAS_WAIT_FOR_COMPLETION_IO_TIMEOUT 1
#define KFEATURE_HAS_WAIT_FOR_COMPLETION_IO 1
#define KFEATURE_CHANGE_QDEPTH_HAS_REASON 0
#define KFEATURE_CHANGE_QUEUE_TYPE 0
#define KFEATURE_HAS_2011_03_QUEUECOMMAND 1
#define KFEATURE_HAS_HOST_LOCKLESS_FIELD 0
#define KFEATURE_HAS_SMP_LOCK_H 0 /* include/linux/smp_lock.h removed between 2.6.38 and 2.6.39 */
#define KFEATURE_HAS_IRQ_SET_AFFINITY_HINTS 1
#define KFEATURE_HAS_ALLOC_WORKQUEUE 1
#define KFEATURE_HAS_ATOMIC_DEC_IF_POSITIVE 1
#define KFEATURE_HAS_PHY_SETUP_AND_RELEASE 1
#define SA_CONTROLLERS_GEN6 1
#define scsi_adjust_queue_depth(a, b, c) scsi_change_queue_depth(a, c)
#define change_queue_type
#define KFEATURE_HAS_PCI_ENABLE_MSIX_RANGE 0
#define KFEATURE_HAS_BLK_RQ_FUNCTIONS 0
#define KFEATURE_HAS_EH_TIMEOUT 1
#define KFEATURE_HAS_ENABLE_CLUSTERING 1
#define HPSA_IOCTL_INT int
/* --- end of default kernel.org & KCLASS4B --- */

#endif 

#if !KFEATURE_HAS_WAIT_FOR_COMPLETION_IO_TIMEOUT
static inline unsigned long wait_for_completion_io_timeout(struct completion *x,
			__attribute__((unused)) unsigned long timeout)
{
	return wait_for_completion_timeout(x, timeout);
}
#endif

#if !KFEATURE_HAS_WAIT_FOR_COMPLETION_IO
static inline unsigned long wait_for_completion_io(struct completion *x)
{
	wait_for_completion(x);
	return 0;
}
#endif

#if KFEATURE_HAS_2011_03_INTERRUPT_HANDLER
	/* new style interrupt handler */
#	define DECLARE_INTERRUPT_HANDLER(handler) \
		static irqreturn_t handler(int irq, void *queue)
#	define INTERRUPT_HANDLER_TYPE(handler) \
		irqreturn_t (*handler)(int, void *)
#else
	/* old style interrupt handler */
#	define DECLARE_INTERRUPT_HANDLER(handler) \
		static irqreturn_t handler(int irq, void *queue, \
			struct pt_regs *regs)
#	define INTERRUPT_HANDLER_TYPE(handler) \
		irqreturn_t (*handler)(int, void *, struct pt_regs *)
#endif


#if KFEATURE_CHANGE_QDEPTH_HAS_REASON
#	define DECLARE_CHANGE_QUEUE_DEPTH(func) \
	static int func(struct scsi_device *sdev, \
		int qdepth, int the_reason)
#	define SET_QUEUE_DEPTH_REASON(reason) \
		((reason) = (the_reason))
/* scsi host template change_queue_depth function */
DECLARE_CHANGE_QUEUE_DEPTH(hpsa_change_queue_depth)
{
        int reason = -1;

        SET_QUEUE_DEPTH_REASON(reason); /* This sets reason */

        if (reason == SCSI_QDEPTH_DEFAULT || reason == SCSI_QDEPTH_RAMP_UP) {
                struct hpsa_scsi_dev_t *logical_drive = sdev->hostdata;

                if (!logical_drive)
                        return -ENODEV;

                if (qdepth < 1)
                        qdepth = 1;
                else if (qdepth > logical_drive->queue_depth)
                        qdepth = logical_drive->queue_depth;

                scsi_adjust_queue_depth(sdev, scsi_get_tag_type(sdev), qdepth);
        } else if (reason == SCSI_QDEPTH_QFULL)
                scsi_track_queue_full(sdev, qdepth);
        else
                return -ENOTSUPP;

        return sdev->queue_depth;
}

#else
#	define DECLARE_CHANGE_QUEUE_DEPTH(func) \
	static int func(struct scsi_device *sdev, int qdepth)
#	define SET_QUEUE_DEPTH_REASON(reason) \
		((reason) = -1)
static int hpsa_change_queue_depth(struct scsi_device *sdev, int qdepth)
{
        struct hpsa_scsi_dev_t *logical_drive = sdev->hostdata;

        if (!logical_drive)
                return -ENODEV;

        if (qdepth < 1)
                qdepth = 1;
        else if (qdepth > logical_drive->queue_depth)
                qdepth = logical_drive->queue_depth;

        return scsi_change_queue_depth(sdev, qdepth);
}

#endif

#if KFEATURE_CHANGE_QUEUE_TYPE
#	define DECLARE_CHANGE_QUEUE_TYPE(func) .change_queue_type = func,
static int hpsa_change_queue_type(struct scsi_device *sdev, int tag_type)
{
        if (sdev->tagged_supported) {
                scsi_set_tag_type(sdev, tag_type);
                if (tag_type)
                        scsi_activate_tcq(sdev, sdev->queue_depth);
                else
                        scsi_deactivate_tcq(sdev, sdev->queue_depth);
        } else
                tag_type = 0;

        return tag_type;
}

#else
#	define DECLARE_CHANGE_QUEUE_TYPE(func)
#endif


#if KFEATURE_HAS_2011_03_STYLE_DEVICE_ATTR

#	define DECLARE_DEVATTR_SHOW_FUNC(func) \
		static ssize_t func(struct device *dev, \
			struct device_attribute *attr, char *buf)

#	define DECLARE_DEVATTR_STORE_FUNC(func) \
	static ssize_t func(struct device *dev, \
		struct device_attribute *attr, const char *buf, size_t count)

#	define DECLARE_HOST_DEVICE_ATTR(xname, xmode, xshow, xstore) \
		static DEVICE_ATTR(xname, xmode, xshow, xstore)

#	define DECLARE_HOST_ATTR_LIST(xlist) \
	static struct device_attribute *xlist[]
#else /* not KFEATURE_HAS_2011_03_STYLE_DEVICE_ATTR */

#	define DECLARE_DEVATTR_SHOW_FUNC(func) \
	static ssize_t func(struct class_device *dev, char *buf)

#	define DECLARE_DEVATTR_STORE_FUNC(func) \
	static ssize_t func(struct class_device *dev, \
		const char *buf, size_t count)

#	define DECLARE_HOST_DEVICE_ATTR(xname, xmode, xshow, xstore) \
	struct class_device_attribute dev_attr_##xname = {\
		.attr = { \
			.name = #xname, \
			.mode = xmode, \
		}, \
		.show = xshow, \
		.store = xstore, \
	};

#	define DECLARE_HOST_ATTR_LIST(xlist) \
	static struct class_device_attribute *xlist[]

#endif /* KFEATURE_HAS_2011_03_STYLE_DEVICE_ATTR */

#ifndef SCSI_QDEPTH_DEFAULT
#	define SCSI_QDEPTH_DEFAULT 0
#endif

#if !KFEATURE_HAS_SCSI_FOR_EACH_SG
#	define scsi_for_each_sg(cmd, sg, nseg, __i) \
	for (__i = 0, sg = scsi_sglist(cmd); __i < (nseg); __i++, (sg)++)
#endif

#if !KFEATURE_HAS_SHOST_PRIV
	static inline void *shost_priv(struct Scsi_Host *shost)
	{
		return (void *) shost->hostdata;
	}
#endif

#if !KFEATURE_HAS_SCSI_DMA_FUNCTIONS
	/* Does not have things like scsi_dma_map, scsi_dma_unmap, scsi_sg_count,
	 * sg_dma_address, sg_dma_len...
	 */

static void hpsa_map_sg_chain_block(struct ctlr_info *h,
	struct CommandList *c);

/* It is not reasonably possible to retrofit the new scsi dma interfaces
 * onto the old code.  So we retrofit at a higher level, at the dma mapping
 * function of the hpsa driver itself.
 *
 * hpsa_scatter_gather takes a struct scsi_cmnd, (cmd), and does the pci
 * dma mapping  and fills in the scatter gather entries of the
 * hpsa command, cp.
 */
static int hpsa_scatter_gather(struct ctlr_info *h,
		struct CommandList *cp,
		struct scsi_cmnd *cmd)
{
	unsigned int len;
	u64 addr64;
	int use_sg, i, sg_index, chained = 0;
	struct SGDescriptor *curr_sg;
	struct scatterlist *sg = (struct scatterlist *) cmd->request_buffer;

	if (!cmd->use_sg) {
		if (cmd->request_bufflen) { /* Just one scatter gather entry */
			addr64 = (__u64) pci_map_single(h->pdev,
				cmd->request_buffer, cmd->request_bufflen,
				cmd->sc_data_direction);

			cp->SG[0].Addr.lower =
				(__u32) (addr64 & (__u64) 0x0FFFFFFFF);
			cp->SG[0].Addr.upper =
				(__u32) ((addr64 >> 32) & (__u64) 0x0FFFFFFFF);
			cp->SG[0].Len = cmd->request_bufflen;
			use_sg = 1;
		} else /* Zero sg entries */
			use_sg = 0;
	} else {
		BUG_ON(cmd->use_sg > h->maxsgentries);

		/* Many sg entries */
		use_sg = pci_map_sg(h->pdev, cmd->request_buffer, cmd->use_sg,
				cmd->sc_data_direction);

		if (use_sg < 0)
			return use_sg;

		sg_index = 0;
		curr_sg = cp->SG;
		use_sg = cmd->use_sg;

		for (i = 0; i < use_sg; i++) {
			if (i == h->max_cmd_sg_entries - 1 &&
				use_sg > h->max_cmd_sg_entries) {
				chained = 1;
				curr_sg = h->cmd_sg_list[cp->cmdindex];
				sg_index = 0;
			}
			addr64 = (__u64) sg_dma_address(&sg[i]);
			len  = sg_dma_len(&sg[i]);
			curr_sg->Addr.lower =
				(u32) (addr64 & 0x0FFFFFFFFULL);
			curr_sg->Addr.upper =
				(u32) ((addr64 >> 32) & 0x0FFFFFFFFULL);
			curr_sg->Len = len;
			curr_sg->Ext = 0;  /* we are not chaining */
			curr_sg++;
		}
	}

	if (use_sg + chained > h->maxSG)
		h->maxSG = use_sg + chained;

	if (chained) {
		cp->Header.SGList = h->max_cmd_sg_entries;
		cp->Header.SGTotal = (u16) (use_sg + 1);
		hpsa_map_sg_chain_block(h, cp);
		return 0;
	}

	cp->Header.SGList = (u8) use_sg;   /* no. SGs contig in this cmd */
	cp->Header.SGTotal = (u16) use_sg; /* total sgs in this cmd list */
	return 0;
}

static void hpsa_unmap_sg_chain_block(struct ctlr_info *h,
	struct CommandList *c);
static void hpsa_scatter_gather_unmap(struct ctlr_info *h,
	struct CommandList *c, struct scsi_cmnd *cmd)
{
	union u64bit addr64;

	if (cmd->use_sg) {
		pci_unmap_sg(h->pdev, cmd->request_buffer, cmd->use_sg,
			cmd->sc_data_direction);
		if (c->Header.SGTotal > h->max_cmd_sg_entries)
			hpsa_unmap_sg_chain_block(h, c);
		return;
	}
	if (cmd->request_bufflen) {
		addr64.val32.lower = c->SG[0].Addr.lower;
		addr64.val32.upper = c->SG[0].Addr.upper;
		pci_unmap_single(h->pdev, (dma_addr_t) addr64.val,
		cmd->request_bufflen, cmd->sc_data_direction);
	}
}

static inline void scsi_dma_unmap(struct scsi_cmnd *cmd)
{
	struct CommandList *c = (struct CommandList *) cmd->host_scribble;

	hpsa_scatter_gather_unmap(c->h, c, cmd);
}

#endif

#if !KFEATURE_HAS_SCSI_DEVICE_TYPE
	/**
	 * scsi_device_type - Return 17 char string indicating device type.
	 * @type: type number to look up
	 */
	const char *scsi_device_type(unsigned type)
	{
		if (type == 0x1e)
			return "Well-known LUN   ";
		if (type == 0x1f)
			return "No Device        ";
		if (type >= ARRAY_SIZE(scsi_device_types))
			return "Unknown          ";
		return scsi_device_types[type];
	}
#endif

#if KFEATURE_SCAN_START_IMPLEMENTED
	/* .scan_start is present in scsi host template AND implemented.
	 * Used to bail out of queuecommand if no scan_start and REPORT_LUNS
	 * encountered
	 */
	static inline int hpsa_dummy_function_returning_zero(void)
	{
		return 0;
	}

#define bail_on_report_luns_if_no_scan_start(cmd, done) \
		hpsa_dummy_function_returning_zero()

	/* RHEL6, kernel.org have functioning ->scan_start() method in kernel
	 * so this is no-op.
	 */
	static inline void hpsa_initial_update_scsi_devices(
		__attribute__((unused)) struct ctlr_info *h)
	{
		return;
	}
#else /* not KFEATURE_SCAN_START_IMPLEMENTED */
	static inline int bail_on_report_luns_if_no_scan_start(
		struct scsi_cmnd *cmd, void (*done)(struct scsi_cmnd *))
	{
		/*
		 * This thing bails out of our queue command early on SCSI
		 * REPORT_LUNS This is needed when the kernel doesn't really
		 * support the scan_start method of the scsi host template.
		 *
		 * Since we do our own mapping in our driver, and we handle
		 * adding/removing of our own devices.
		 *
		 * We want to prevent the mid-layer from doing it's own
		 * adding/removing of drives which is what it would do
		 * if we allow REPORT_LUNS to be processed.
		 *
		 * On RHEL5, scsi mid-layer never calls scan_start and
		 * scan_finished even though they exist in scsi_host_template.
		 *
		 * On RHEL6 we use scan_start and scan_finished to tell
		 * mid-layer that we do our own device adding/removing
		 * therefore we can handle REPORT_LUNS.
		 */

		if (cmd->cmnd[0] == REPORT_LUNS) {
			cmd->result = (DID_OK << 16);           /* host byte */
			cmd->result |= (COMMAND_COMPLETE << 8); /* msg byte */
			cmd->result |= SAM_STAT_CHECK_CONDITION;
			memset(cmd->sense_buffer, 0, sizeof(cmd->sense_buffer));
			cmd->sense_buffer[2] = ILLEGAL_REQUEST;
			done(cmd);
			return 1;
		}
		return 0;
	}

	/* Need this if no functioning ->scan_start() method in kernel. */
	static void hpsa_update_scsi_devices(struct ctlr_info *h, int hostno);
	static inline void hpsa_initial_update_scsi_devices(
				struct ctlr_info *h)
	{
		hpsa_update_scsi_devices(h, -1);
	}
#endif /* KFEATURE_SCAN_START_IMPLEMENTED */

#if KFEATURE_SCAN_START_PRESENT
	/* .scan_start is present in scsi host template */
	#define INITIALIZE_SCAN_START(funcptr) .scan_start = funcptr,
	#define INITIALIZE_SCAN_FINISHED(funcptr) .scan_finished = funcptr,
#else /* .scan start is not even present in scsi host template */
	#define INITIALIZE_SCAN_START(funcptr)
	#define INITIALIZE_SCAN_FINISHED(funcptr)
#endif

#if KFEATURE_HAS_2011_03_QUEUECOMMAND
#	define DECLARE_QUEUECOMMAND(func) \
		static int func(struct Scsi_Host *sh, struct scsi_cmnd *cmd)
#	define hpsa_scsi_done(cmd, done) \
		(cmd)->scsi_done((cmd))
#	define hpsa_save_scsi_done(cmd, done)
#else
#	define DECLARE_QUEUECOMMAND(func) \
	static int func(struct scsi_cmnd *cmd, void (*done)(struct scsi_cmnd *))
#	define hpsa_scsi_done(cmd, done) \
		done((cmd))
#	define hpsa_save_scsi_done(cmd, done) \
		(cmd)->scsi_done = (done)
#endif

#if KFEATURE_HAS_HOST_LOCKLESS_FIELD
#	define HPSA_SKIP_HOST_LOCK .lockless = 1,
#else
#	define HPSA_SKIP_HOST_LOCK
#endif

#if !KFEATURE_HAS_SCSI_SET_RESID
	static inline void scsi_set_resid(struct scsi_cmnd *cmd, int resid)
	{
		cmd->resid = resid;
	}
#endif

#ifndef DMA_BIT_MASK
#define DMA_BIT_MASK(n) (((n) == 64) ? ~0ULL : ((1ULL<<(n))-1))
#endif

/* Define old style irq flags SA_* if the IRQF_* ones are missing. */
#ifndef IRQF_DISABLED
#define IRQF_DISABLED (SA_INTERRUPT | SA_SAMPLE_RANDOM)
#endif

#if KFEATURE_HAS_UACCESS_H_FILE
#include <linux/uaccess.h>
#endif

#if KFEATURE_HAS_SMP_LOCK_H
#include <linux/smp_lock.h>
#endif

/*
 * Support for packaged storage solutions.
 * Enabled by default for kernel.org 
 * Enable above as required for distros.
 */
#if HPSA_SUPPORTS_STORAGEWORKS_1210m
#define HPSA_STORAGEWORKS_1210m_PCI_IDS \
	{PCI_VENDOR_ID_HP, PCI_DEVICE_ID_HP_CISSE, 0x103C, 0x3233}, \
	{PCI_VENDOR_ID_HP, PCI_DEVICE_ID_HP_CISSF, 0x103C, 0x333F},	\
	{PCI_VENDOR_ID_3PAR,	PCI_DEVICE_ID_3PAR,	0x1590, 0x0076},\
	{PCI_VENDOR_ID_3PAR,	PCI_DEVICE_ID_3PAR,	0x1590, 0x007d},\
	{PCI_VENDOR_ID_3PAR,	PCI_DEVICE_ID_3PAR,	0x1590, 0x0077},\
	{PCI_VENDOR_ID_3PAR,	PCI_DEVICE_ID_3PAR,	0x1590, 0x0087},\
	{PCI_VENDOR_ID_3PAR,	PCI_DEVICE_ID_3PAR,	0x1590, 0x0088},\
	{PCI_VENDOR_ID_3PAR,	PCI_DEVICE_ID_3PAR,	0x1590, 0x0089},

#define HPSA_STORAGEWORKS_1210m_PRODUCT_ENTRIES \
	{0x3233103C, "HP StorageWorks 1210m", &SA5_access}, \
	{0x333F103C, "HP StorageWorks 1210m", &SA5_access}, \
   {0x00761590, "HP Storage P1224 Array Controller", &SA5_access}, \
   {0x007d1590, "HP Storage P1228 Array Controller", &SA5_access}, \
   {0x00771590, "HP Storage P1228m Array Controller", &SA5_access}, \
   {0x00871590, "HP Storage P1224e Array Controller", &SA5_access}, \
   {0x00881590, "HP Storage P1228e Array Controller", &SA5_access}, \
   {0x00891590, "HP Storage P1228em Array Controller", &SA5_access},
   

#else
#define HPSA_STORAGEWORKS_1210m_PCI_IDS	
#define HPSA_STORAGEWORKS_1210m_PRODUCT_ENTRIES
#endif

/* sles10sp4 apparently doesn't have DIV_ROUND_UP.  Normally it comes
 * from include/linux/kernel.h.  Other sles10's have it I think.
 */
#if !defined(DIV_ROUND_UP)
#define DIV_ROUND_UP(n,d) (((n) + (d) - 1) / (d))
#endif

/* Newer dma_mapping_error function takes 2 args, older version only takes 1 arg.
 * This macro makes the code do the right thing depending on which variant we have.
 */
#if KFEATURE_HAS_NEW_DMA_MAPPING_ERROR
#define hpsa_dma_mapping_error(x, y) dma_mapping_error(x, y)
#else
#define hpsa_dma_mapping_error(x, y) dma_mapping_error(y)
#endif

#if !KFEATURE_HAS_IRQ_SET_AFFINITY_HINTS
#define irq_set_affinity_hint(irq, cpu) (0)
#endif

#if !KFEATURE_HAS_ALLOC_WORKQUEUE
/* Earlier implementations had no concept of WQ_MEM_RECLAIM so far as I know.
 * FIXME: RHEL6 does not have WQ_MEM_RECLAIM flag.  What to do about this?
 * WQ_MEM_RECLAIM is supposed to reserve a "rescue thread" so that the work
 * queue can always make forward progress even in low memory situations. E.g.
 * if OS is scrambling for memory and trying to swap out to disk, it is bad if
 * the thread that is doing the swapping i/o needs to allocate.
 */
#define WQ_MEM_RECLAIM (0)
#define alloc_workqueue(name, flags, max_active) __create_workqueue(name, flags, max_active, 0)
#endif

#if !KFEATURE_HAS_ATOMIC_DEC_IF_POSITIVE
static inline int atomic_dec_if_positive(atomic_t *v)
{
	int c, old, dec;
	c = atomic_read(v);
	for (;;) {
		dec = c - 1;
		if (unlikely(dec < 0))
			break;
		old = atomic_cmpxchg((v), c, dec);
		if (likely(old == c))
			break;
		c = old;
	}
	return dec;
}
#endif

#if !defined(KFEATURE_HAS_BLK_RQ_FUNCTIONS)
#define KFEATURE_HAS_BLK_RQ_FUNCTIONS 0
bool blk_rq_is_passthrough(struct request *rq)
{
	return rq->cmd_type != REQ_TYPE_FS;
}
#endif

#if !defined(KFEATURE_HAS_PCI_ENABLE_MSIX_RANGE)
#define KFEATURE_HAS_PCI_ENABLE_MSIX_RANGE 0
int pci_enable_msix_range(struct pci_dev *pci_dev, struct msix_entry *entries,
	int minvec, int maxvec)
{
	int nvec = maxvec;
	int rc;

	if (maxvec < minvec)
		return -ERANGE;

	do {
		rc = pci_enable_msix(pci_dev, entries, nvec);
		if (rc < 0)
			return rc;
		if (rc > 0) {
			if (rc < minvec)
				return -ENOSPC;
			nvec = rc;
		}
	} while (rc);

	return nvec;
}
#endif

#if !defined(KFEATURE_HAS_NEWER_ALLOC_ORDERED_WORKQUEUE)
#define KFEATURE_HAS_NEWER_ALLOC_ORDERED_WORKQUEUE 0
#if defined(SLES11sp1) || defined(SLES11SP1)
#define alloc_ordered_workqueue(name, flags) __create_workqueue(name, flags, 0, 0)
#endif
static struct workqueue_struct *hpsa_create_controller_wq(struct ctlr_info *h,
						char *name)
{
	struct workqueue_struct *wq = NULL;
	char wq_name[30];

	sprintf(wq_name, "hpsa_%s_%d", name, h->ctlr);

	wq = alloc_ordered_workqueue(wq_name, 0);
	if (!wq)
		dev_err(&h->pdev->dev, "failed to create %s workqueue\n", name);

	return wq;
}
#else /* Newer style API */
static struct workqueue_struct *hpsa_create_controller_wq(struct ctlr_info *h,
						char *name)
{
	struct workqueue_struct *wq = NULL;

	wq = alloc_ordered_workqueue("hpsa_%s_%d", 0, name, h->ctlr);
	if (!wq)
		dev_err(&h->pdev->dev, "failed to create %s workqueue\n", name);

	return wq;
}
#endif /* KFEATURE_HAS_NEWER_ALLOC_ORDERED_WORKQUEUE */

void hpsa_increase_ctlr_timeout(struct scsi_device *sdev, u32 timeout)
{
#if !KFEATURE_HAS_EH_TIMEOUT
	blk_queue_rq_timeout(sdev->request_queue, timeout);
#else
	sdev->eh_timeout = timeout;
	blk_queue_rq_timeout(sdev->request_queue, timeout);
#endif
	return;
}

void hpsa_increase_device_timeout(struct scsi_device *sdev, u32 timeout)
{
#if !KFEATURE_HAS_EH_TIMEOUT
	blk_queue_rq_timeout(sdev->request_queue, timeout);
#else
	sdev->eh_timeout = timeout;
	blk_queue_rq_timeout(sdev->request_queue, timeout);
#endif
}

void hpsa_compat_init_scsi_host_template(struct scsi_host_template *hostt)
{
#if KFEATURE_HAS_ENABLE_CLUSTERING
	hostt->use_clustering = ENABLE_CLUSTERING;
#endif
}

/* these next three disappeared in 3.8-rc4 */
#ifndef __devinit
#define __devinit
#endif

#ifndef __devexit
#define __devexit
#endif

#ifndef __devexit_p
#define __devexit_p(x) x
#endif

#if !defined(TYPE_ZBC)
#define TYPE_ZBC            0x14
#endif

/* Kernel.org since about July 2013 has nice %XphN formatting for bytes
 * Older kernels don't.  So we have this instead.
 */
#define phnbyte(x, n) ((int) ((x)[(n)]))
#define phN16 "%02hhx%02hhx%02hhx%02hhx%02hhx%02hhx%02hhx%02hhx%02hhx%02hhx%02hhx%02hhx%02hhx%02hhx%02hhx%02hhx"
#define phNbytes16(x) \
	phnbyte((x), 0), phnbyte((x), 1), phnbyte((x), 2), phnbyte((x), 3), \
	phnbyte((x), 4), phnbyte((x), 5), phnbyte((x), 6), phnbyte((x), 7), \
	phnbyte((x), 8), phnbyte((x), 9), phnbyte((x), 10), phnbyte((x), 11), \
	phnbyte((x), 12), phnbyte((x), 13), phnbyte((x), 14), phnbyte((x), 15)

